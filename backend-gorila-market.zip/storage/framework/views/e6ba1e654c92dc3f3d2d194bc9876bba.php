

<?php $__env->startSection('title', 'Categorias'); ?>

<?php $__env->startSection('plugins.Sweetalert2', true); ?>


<?php $__env->startSection('content_header'); ?>
    <h1>Categorias</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php if(session('mensaje')): ?>
            <div class="alert alert-success">
                <?php echo e(session('mensaje')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <strong><?php echo e(session('error')); ?></strong>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-4">
                <ul id="categorias" data-widget="treeview">
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(sizeof($categoria->sub_categorias) > 0): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('categoria.modificar', ['id' => $categoria->idcategorias])); ?>"
                                    class="nav-link modificar-cat"
                                    data-id="<?php echo e($categoria->idcategorias); ?>"><?php echo e($categoria->nombre); ?></a>
                                <ul class="nav-treeview">
                                    <?php $__currentLoopData = $categoria->sub_categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(route('categoria.modificar', ['id' => $sub_categoria->idcategorias])); ?>"
                                                class="modificar-cat"><?php echo e($sub_categoria->nombre); ?></a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                        <?php else: ?>
                            <li><a href="<?php echo e(route('categoria.modificar', ['id' => $categoria->idcategorias])); ?>"
                                    class="modificar-cat">
                                    <?php echo e($categoria->nombre); ?>

                                </a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="col-2"></div>
            <div class="col-6">
                <div class="card card-verde">
                    <div class="card-header">
                        <h3 class="card-title">Agregar Categoria</h3>
                    </div>
                    <form method="POST" action="<?php echo e(route('categoria.agregar')); ?>">
                        <div class="card-body">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row ">
                                <label for="nombre" class="col-4 col-form-label">Nombre</label>
                                <div class="col">
                                    <input id="nombre" type="text"
                                        class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nombre"
                                        value="<?php echo e(old('nombre')); ?>" autocomplete="nombre" autofocus>
                                    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row ">
                                <label for="tipo" class="col-4 col-form-label">Tipo</label>
                                <div class="col">
                                    <select id="tipo" class="form-control <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="tipo">
                                        <option value="1" <?php if(old('tipo') == '1'): ?> selected <?php endif; ?>>Categoria
                                            Superior</option>
                                        <option value="2" <?php if(old('tipo') == '2'): ?> selected <?php endif; ?>>Categoria
                                            Inferior</option>
                                    </select>
                                    <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group row <?php if(old('tipo') != '2'): ?> d-none <?php endif; ?>" id="cat_general">
                                <label for="padre_gen" class="col-4 col-form-label">Categoria General</label>
                                <div class="col">
                                    <select id="padre_gen" class="form-control <?php $__errorArgs = ['padre_gen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="padre_gen">
                                        <option value="" class="d-none">Seleccione</option>
                                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($categoria->idcategorias); ?>"
                                                <?php if(old('padre_gen') == $categoria->idcategorias): ?> selected <?php endif; ?>><?php echo e($categoria->nombre); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['padre_gen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer text-right">
                            <button type="submit" class="btn btn-primary btn-verde">Agregar</button>
                        </div>
                    </form>
                </div>
                <div id="modificar-categoria">
                    <?php if(old('m_idcategorias') !== null): ?>
                        <?php echo $__env->make('categorias.ajax.modificar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/app.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $('ul#categorias').Treeview();
        $(document).ready(function(e) {
            $("#tipo").change(function(e) {
                if ($(this).val() == "2") {
                    $("#cat_general").removeClass("d-none");
                } else {
                    $("#cat_general").addClass("d-none");
                }
            });
            $("body").on("change", "#m_tipo", function(e) {
                if ($(this).val() == "2") {
                    $("#m_cat_general").removeClass("d-none");
                } else {
                    $("#m_cat_general").addClass("d-none");
                }
            });
            $("body").on("click", "#eliminar", function(e) {
                e.preventDefault();
                const link = $(this).prop("href");
                Swal.fire({
                    title: '<b>Eliminar Categoria</b>',
                    type: 'warning',
                    text: 'En verdad desea eliminar esta categoria?',
                    showCloseButton: true,
                    showCancelButton: true,
                    confirmButtonText: 'Eliminar',
                    cancelButtonText: 'Cancelar',
                    confirmButtonColor: 'var(--color-verde)'
                }).then((result) => {
                    if (result.value) {
                        window.open(link,'_self');
                    }
                });
            });

            $(".modificar-cat").click(function(e) {
                e.preventDefault();
                $.ajax({
                        url: $(this).prop("href"),
                        cache: false
                    })
                    .done(function(html) {
                        $("#modificar-categoria").html(html);
                    });
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/categorias/inicio.blade.php ENDPATH**/ ?>