

<?php $__env->startSection('title', 'Productos'); ?>

<?php $__env->startSection('plugins.Sweetalert2', true); ?>
<?php $__env->startSection('plugins.Datatables', true); ?>


<?php $__env->startSection('content_header'); ?>
    <div class="row">
        <div class="col-12 col-md-8">
            <h1>Productos</h1>
        </div>
        <div class="col-12 col-md-4 text-right">
            <a href="<?php echo e(route('producto.masivo')); ?>" class="btn btn-outline-azul">Cargue Masivo</a>
            <a href="<?php echo e(route('producto.agregar')); ?>" class="btn btn-outline-azul">Agregar Producto</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php if(session('mensaje')): ?>
            <div class="alert alert-success">
                <?php echo e(session('mensaje')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <strong><?php echo e(session('error')); ?></strong>
            </div>
        <?php endif; ?>

    </div>
    <table class="table table-striped" id="tabla">
        <thead>
            <tr>
                <th>ID</th>
                <th>Cod. Barras</th>
                <th>Nombre</th>
                <th>Precio</th>
                <th>Precio Distribuidor</th>
                <th>Und. Medida</th>
                <th>Estado</th>
                <th>Orden</th>
                <th>Categoria</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($producto->idproducto); ?></td>
                    <td><?php echo e($producto->cd_barras); ?></td>
                    <td><?php echo e($producto->nombre); ?></td>
                    <td>$<?php echo e(number_format($producto->precio, 0)); ?></td>
                    <td>$<?php echo e(number_format($producto->precioDist, 0)); ?></td>
                    <td><?php echo e($producto->descripcion); ?></td>
                    <td><?php echo e($producto->visible); ?></td>
                    <td><?php echo e($producto->orden); ?></td>
                    <td><?php echo e($producto->categoria->nombre); ?></td>
                    <td data-priority="0" style="white-space: nowrap">
                        <a href="<?php echo e(route('producto.modificar', ['id' => $producto->idproducto])); ?>" class="btn btn-verde"
                            data-toggle="tooltip" data-placement="top" title="Editar"><i class="fas fa-edit"></i></a>
                        <a href="<?php echo e(route('producto.fotos', ['id' => $producto->idproducto])); ?>" class="btn btn-verde" data-toggle="tooltip" data-placement="top"
                            title="Editar Fotos"><i class="fas fa-images"></i></a>
                        <a href="<?php echo e(route('producto.eliminar', ['id' => $producto->idproducto])); ?>" class="btn btn-danger eliminar" data-toggle="tooltip" data-placement="top"
                            title="Eliminar"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/app.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(function() {
            $('[data-toggle="tooltip"]').tooltip()
        });
        $('#tabla').DataTable({
            responsive: true,
            order: [
                [2, 'asc']
            ],
            language: {
                url: 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/es-MX.json'
            }
        });

        $('#tabla').on('draw.dt', function() {
            $('[data-toggle="tooltip"]').tooltip();
        });
        $("body").on("click",".eliminar",function(e){
            e.preventDefault();
            const link = $(this).attr("href");
            Swal.fire({
                title: '<b>Eliminar Producto</b>',
                type: 'warning',
                text: 'En verdad desea eliminar este producto?',
                showCloseButton: true,
                showCancelButton: true,
                confirmButtonText: 'Eliminar',
                cancelButtonText: 'Cancelar',
                confirmButtonColor: 'var(--color-verde)'
            }).then((result) => {
                if (result.value) {
                    window.open(link,'_self');
                }
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/productos/tabla.blade.php ENDPATH**/ ?>