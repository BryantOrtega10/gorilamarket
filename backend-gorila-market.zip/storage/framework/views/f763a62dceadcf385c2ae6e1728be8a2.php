

<?php $__env->startSection('title'); ?>
    Pagar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mi-carrito-completo">
        <div class="row">
            <div class="col-12 col-md-6 px-3">
                <h1>Mi Pedido</h1>
                <div class="productos-carrito">
                    <?php $__currentLoopData = $carrito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="producto" data-id="<?php echo e($producto->idproducto); ?>">
                            <div class="row">
                                <div class="col-auto">
                                    <div class="imagen">
                                        <?php if($producto->fotoPpal() !== null && Storage::disk('public')->exists('productos/min_' . $producto->fotoPpal()->ruta)): ?>
                                            <img src="<?php echo e(Storage::url('productos/min_' . $producto->fotoPpal()->ruta)); ?>"
                                                alt="<?php echo e($producto->nombre); ?>" loading="lazy" />
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('img/web/placeholder-producto.png')); ?>" loading="lazy" />
                                        <?php endif; ?>
                                    </div>
                                    <?php if($producto->promocion() !== null && intval($producto->promocion()->porcentaje) > 0): ?>
                                        <div class="espacio-promo">
                                            <div class="porcentaje-promocion">
                                                <?php echo e($producto->promocion()->porcentaje); ?> %</div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="col py-4">
                                    <div class="row">
                                        <div class="col-12">
                                            <strong><?php echo e($producto->nombre); ?></strong>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <span><?php echo e($producto->descripcion); ?></span><br><br>
                                            <div class="row">
                                                <div class="col-12">
                                                    <a href="<?php echo e(route('web.quitarCarrito', ['id' => $producto->idproducto])); ?>"
                                                        class="menos-unidades"><i class="fa-solid fa-minus"></i></a>
                                                    <span class="cant-productos-carrito"
                                                        data-id="<?php echo e($producto->idproducto); ?>"><?php echo e(Session::get('carrito')->productos[$producto->idproducto]); ?></span>
                                                    <a href="<?php echo e(route('web.agregarCarrito', ['id' => $producto->idproducto])); ?>"
                                                        class="mas-unidades"><i class="fa-solid fa-plus"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 text-center">
                                            <?php if($producto->promocion() === null): ?>
                                                <div><b class="precio1" data-id="<?php echo e($producto->idproducto); ?>">$
                                                        <?php echo e(number_format($producto->precioClDi() * Session::get('carrito')->productos[$producto->idproducto], 0, '.', '.')); ?></b>
                                                    <s class="precio2 d-none" data-id="<?php echo e($producto->idproducto); ?>">$
                                                        <?php echo e(number_format($producto->precioClDi() * Session::get('carrito')->productos[$producto->idproducto], 0, '.', '.')); ?></s>
                                                </div>
                                            <?php else: ?>
                                                <div><b class="precio1" data-id="<?php echo e($producto->idproducto); ?>">$
                                                        <?php echo e(number_format($producto->precioPromo() * Session::get('carrito')->productos[$producto->idproducto], 0, '.', '.')); ?></b>
                                                </div><br>
                                                <div><s class="precio2" data-id="<?php echo e($producto->idproducto); ?>">$
                                                        <?php echo e(number_format($producto->precioClDi() * Session::get('carrito')->productos[$producto->idproducto], 0, '.', '.')); ?></s>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="quitar-producto"
                                        data-url="<?php echo e(route('web.quitarTodoCarrito', ['id' => $producto->idproducto])); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="totales">
                    <div class="row">
                        <div class="col text-start">Subtotal</div>
                        <div class="col text-end subtotal">
                            $<?php echo e(number_format(Session::get('carrito')->subtotal ?? 0, 0, '.', '.')); ?></div>
                    </div>
                    <div class="row domicilio">
                        <div class="col text-start">Costo del domicilio</div>
                        <div class="col text-end costoDomicilio">
                            $<?php echo e(number_format(Session::get('carrito')->costoDomicilio ?? 0, 0, '.', '.')); ?></div>
                    </div>
                    <div class="row">
                        <div class="col text-start">Descuento</div>
                        <div class="col text-end descuento">$<?php echo e(number_format($descuento ?? 0, 0, '.', '.')); ?></div>
                    </div>
                    <div class="row">
                        <div class="col text-start">Total</div>
                        <div class="col text-end total">$<?php echo e(number_format($total ?? 0, 0, '.', '.')); ?></div>
                    </div>
                </div>
                <div class="productos-destacados">
                    <h3>Producto sugerido</h3>
                    <div class="cont-productos-destacados">
                        <?php $__currentLoopData = $productosDestacados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item-no-swipe">
                                <a href="#" class="producto">
                                    <div class="agregar-carrito reload"
                                        data-url="<?php echo e(route('web.agregarCarrito', ['id' => $producto->idproducto])); ?>">
                                        <div class="icono-carrito">
                                            <i class="fa-solid fa-plus"></i>
                                        </div>
                                    </div>
                                    <div class="imagen">
                                        <?php if($producto->fotoPpal() !== null && Storage::disk('public')->exists('productos/min_' . $producto->fotoPpal()->ruta)): ?>
                                            <img src="<?php echo e(Storage::url('productos/min_' . $producto->fotoPpal()->ruta)); ?>"
                                                alt="<?php echo e($producto->nombre); ?>" loading="lazy" />
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('img/web/placeholder-producto.png')); ?>" loading="lazy" />
                                        <?php endif; ?>
                                    </div>
                                    <div class="row">
                                        <?php if($producto->promocion() === null): ?>
                                            <div class="col"><b>$
                                                    <?php echo e(number_format($producto->precioClDi(), 0, '.', '.')); ?></b>
                                            </div>
                                        <?php else: ?>
                                            <div class="col-auto"><b>$
                                                    <?php echo e(number_format($producto->precioPromo(), 0, '.', '.')); ?></b>
                                            </div>
                                            <div class="col"><s>$
                                                    <?php echo e(number_format($producto->precioClDi(), 0, '.', '.')); ?></s>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <strong><?php echo e($producto->nombre); ?></strong><br>
                                    <span><?php echo e($producto->descripcion); ?></span><br>

                                    <?php if($producto->promocion() !== null && intval($producto->promocion()->porcentaje) > 0): ?>
                                        <div class="espacio-promo">
                                            <div class="porcentaje-promocion">
                                                <?php echo e($producto->promocion()->porcentaje); ?> %</div>
                                        </div>
                                    <?php endif; ?>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-6 px-3">
                <div class="datos-pago">
                    <form action="<?php echo e(route('web.pagar')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="item-detalle-pago pago-direccion">
                            <label>Dirección de envío</label>
                            <input type="text" class="form-control" id="direccion_carrito" name="direccion_carrito"
                                placeholder="Escribe tu dirección donde llegara tu pedido" readonly required
                                value="<?php echo e(Session::get('direccion')->direccionCompleta ?? ''); ?>" />
                            <?php $__errorArgs = ['direccion_carrito'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="text" class="form-control" id="direccion_adicional_carrito"
                                name="direccion_adicional_carrito" placeholder="Datos adicionales: Casa, Apartamento..."
                                value="<?php echo e(Session::get('direccion')->adicionales ?? ''); ?>" />
                        </div>
                        <div class="item-detalle-pago pago-cupon">
                            <label>Redimir cupón</label>
                            <div class="row align-items-center mb-2">
                                <div class="col">
                                    <input type="text" id="cupon-txt" class="form-control my-0"
                                        <?php if($successCupon): ?> readonly <?php endif; ?>
                                        placeholder="Registra tu cupón aquí para efectuar el descuento"
                                        value="<?php echo e(Session::get('cupon') ?? ''); ?>" />
                                </div>
                                <?php if(Session::has('cupon')): ?>
                                    <div class="col-auto">
                                        <a class="btn btn-azul quitar-cupon"
                                            href="<?php echo e(route('web.quitarCupon')); ?>">Quitar</a>
                                    </div>
                                <?php else: ?>
                                    <div class="col-auto">
                                        <a class="btn btn-azul verificar-cupon"
                                            href="<?php echo e(route('web.cupon')); ?>">Verificar</a>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <b
                                        class="<?php if($successCupon): ?> text-success <?php else: ?> text-danger <?php endif; ?> respuestaCodigo <?php if(!Session::has('cupon')): ?> d-none <?php endif; ?>"><?php echo e($respuestaTexto); ?></b>
                                </div>
                            </div>
                        </div>
                        <div class="item-detalle-pago pago-fecha-entrega">
                            <label>¿Cuándo quieres recibir tu pedido?</label>
                            <select class="form-select" name="fechaPedido" id="fechaPedido" required>
                                <option value="">Selecciona el día para recibir tu pedido</option>
                                <?php $__currentLoopData = $diasPedido; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diaPedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($diaPedido); ?>"><?php echo e($diaPedido); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <select class="form-select" id="horaPedido" name="horaPedido" required>
                                <option value="">Selecciona la hora para recibir tu pedido</option>
                                <option value="horaMan" <?php if(Session::get('carrito') != null && Session::get('carrito')->horaEntrega == 'horaMan'): ?> selected <?php endif; ?>>Mañana</option>
                                <option value="horaTar" <?php if(Session::get('carrito') != null && Session::get('carrito')->horaEntrega == 'horaTar'): ?> selected <?php endif; ?>>Tarde</option>
                                <option value="horaNoc" <?php if(Session::get('carrito') != null && Session::get('carrito')->horaEntrega == 'horaNoc'): ?> selected <?php endif; ?>>Noche</option>
                            </select>
                        </div>
                        <div class="item-detalle-pago pago-metodo-pago">
                            <label>Método de pago</label>
                            <select class="form-select" name="metodo_pago" id="metodo_pago" required>
                                <option value="">Selecciona la manera más fácil de pagar</option>
                                <option value="efectivo">Efectivo</option>
                                <option value="datafono">Datafono</option>
                            </select>
                        </div>
                        <div class="item-detalle-pago pago-metodo-pago">
                            <label>¿No encontraste lo que buscabas?</label>
                            <textarea class="form-control" name="producto_no_encontrado"
                                placeholder="Escribe tu sugerencias de los productos que deberían estar en Gorilla marker "></textarea>
                        </div>
                        <div class="text-center">
                            <button class="btn btn-verde">Realizar pedido</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web_sin_carrito', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/web/pagar.blade.php ENDPATH**/ ?>