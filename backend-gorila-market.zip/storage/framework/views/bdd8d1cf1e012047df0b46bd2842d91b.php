<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Bienvenido'); ?> | <?php echo e(config('app.name', 'Gorila Market')); ?></title>
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/web.js')); ?>" defer></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous">
    </script>
    <!--Styles -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link href="<?php echo e(asset('css/web.css')); ?>" rel="stylesheet">
    
    <!--FavIcon-->
    <link rel="icon" type="image/vnd.microsoft.icon" href="<?php echo e(asset('img/favicon.ico')); ?>">

    <!-- imports adicionales -->
    <?php echo $__env->yieldContent('imports'); ?>


</head>

<body>
    <nav class="navbar navbar-gorila">
        <div class="navbar-left">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(asset('img/web/logo.png')); ?>" alt="Gorila Market">
            </a>
            <a class="navbar-direccion btn">
                <img src="<?php echo e(asset('img/web/direccion.png')); ?>">
                <?php if(Session::has('direccion')): ?>
                    <?php echo e(Session::get('direccion')->direccionCompleta); ?>

                <?php else: ?>
                    Selecciona una dirección
                <?php endif; ?>
            </a>
        </div>
        <div class="navbar-center">
            <div class="navbar-search">
                <form class="search-form">
                    <?php echo csrf_field(); ?>
                    <input class="form-control" type="text" placeholder="Huevos, arroz, carne, vino"
                        aria-label="Buscador">
                    <button type="submit" class="btn">
                        <img src="<?php echo e(asset('img/web/buscar-azul.png')); ?>" />
                    </button>
                </form>
            </div>
        </div>
        <div class="navbar-right">
            <div class="navbar-buttons">
                <a class="btn btn-icono btn-ingresar">
                    <img src="<?php echo e(asset('img/web/ingresar.png')); ?>">
                    <?php if(auth()->guard()->guest()): ?>
                        <span>Ingresar</span>
                    <?php else: ?>
                        <span>Hola, <?php echo e(Auth::user()->name); ?></span>
                    <?php endif; ?>
                </a>
                <a class="btn btn-icono btn-carrito">
                    <img src="<?php echo e(asset('img/web/carrito.png')); ?>">
                    <span class="cantidad-productos <?php if(!Session::has('carrito') || Session::get('carrito')->cuentaProductos == 0): ?> d-none <?php endif; ?>">0</span>
                    <span>Carrito</span>
                </a>
            </div>
        </div>
    </nav>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <h5>Preguntas frecuentes</h5>
                </div>
                <div class="col-md-3">
                    <h5>Términos y condiciones</h5>
                </div>
                <div class="col-md-3">
                    <h5>Políticas de privacidad</h5>
                </div>
                <div class="col-md-3"></div>
            </div>
        </div>
        <div class="footer-legal">
            <div class="container">
                Todos los derechos reservados <?php echo e(date('Y')); ?> <a href="#">Términos y condiciones</a>
            </div>
        </div>
    </footer>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/layouts/web_cliente.blade.php ENDPATH**/ ?>