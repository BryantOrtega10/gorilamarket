

<?php $__env->startSection('title'); ?>
    Ingresar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container iniciar">
        <div class="row align-content-center vh-100">
            <div class="d-none d-md-block col-md-7">
                <img src="<?php echo e(asset('img/web/inicio.png')); ?>" class="mw-100" />
            </div>
            <div class="align-content-center col-12 col-md-5 d-flex flex-column flex-wrap justify-content-center">
                <div class="text-center"><img src="<?php echo e(asset('img/web/logo_grande.png')); ?>" /></div>
                <h2>Inicia sesión con</h2>
                <a class="btn btn-iniciar-google">Sigue con Google</a>
                <a class="btn btn-iniciar-facebook">Sigue con Facebook</a>
                <div class="seguir_div text-center"><span>o sigue con tu celular</span></div>
                <a class="btn btn-iniciar-celular" href="<?php echo e(route('web.registroCelular')); ?>">Continua con tu celular</a>
                <b class="text-center">¿Ya tienes una cuenta?</b>
                <a class="btn btn-continuar-verde" href="<?php echo e(route('web.cuentaCelular')); ?>">Continuar</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web_sin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/web/ingresar.blade.php ENDPATH**/ ?>