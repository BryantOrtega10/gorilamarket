

<?php $__env->startSection('title'); ?>
    Inicio
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="swiper swiper-web-1">
        <div class="swiper-wrapper">
            <?php $__empty_1 = true; $__currentLoopData = $publicidades_web1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publicidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="swiper-slide">
                    <div class="cont-slide-ppal">
                        <a href="<?php echo e(route('web.verProductoUnico', ['producto' => $publicidad->producto])); ?>"><img src="<?php echo e(Storage::url('imagenes_p/max_' . $publicidad->imagen)); ?>" /></a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="swiper-slide">
                    <div class="cont-slide-ppal"><img src="<?php echo e(asset('img/web/slider-web-1.png')); ?>" /></div>
                </div>
                <div class="swiper-slide">
                    <div class="cont-slide-ppal"><img src="<?php echo e(asset('img/web/slider-web-1.png')); ?>" /></div>
                </div>
                <div class="swiper-slide">
                    <div class="cont-slide-ppal"><img src="<?php echo e(asset('img/web/slider-web-1.png')); ?>" /></div>
                </div>
            <?php endif; ?>
        </div>
    </section>
    <section class="promociones">
        <div class="container">
            <h2 class="text-center">Últimas promociones</h2>
            <?php if(sizeof($promociones) > 4): ?>
                <div class="promociones swiper swiper-promo">
                    <div class="swipper-navigation-container">
                        <div class="gorila-button-next"><i class="fa-solid fa-chevron-right"></i></div>
                        <div class="gorila-button-prev"><i class="fa-solid fa-chevron-left"></i></div>
                    </div>
                    <div class="swiper-wrapper">
                        <?php $__empty_1 = true; $__currentLoopData = $promociones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="swiper-slide">
                                <a href="<?php echo e(route('web.verProductoUnico', ['producto' => $producto])); ?>" class="producto">
                                    <div class="imagen">
                                        <?php if($producto->fotoPpal() !== null && Storage::disk('public')->exists('productos/min_' . $producto->fotoPpal()->ruta)): ?>
                                        <img src="<?php echo e(Storage::url('productos/min_' . $producto->fotoPpal()->ruta)); ?>"
                                            alt="<?php echo e($producto->nombre); ?>" loading="lazy" />
                                        <?php else: ?>
                                        <img src="<?php echo e(asset('img/web/placeholder-producto.png')); ?>" loading="lazy" />
                                        <?php endif; ?>
                                        <div class="lazy-preloader">
                                            <img src="<?php echo e(asset('img/web/placeholder-producto.png')); ?>" />
                                        </div>
                                    </div>
                                    <div class="row">
                                        <?php if($producto->promocion() !== null): ?>
                                            <div class="col"><b>$
                                                    <?php echo e(number_format($producto->precioClDi(), 0, '.', '.')); ?></b>
                                            </div>
                                        <?php else: ?>
                                            <div class="col"><b>$
                                                    <?php echo e(number_format($producto->precioPromo(), 0, '.', '.')); ?></b>
                                            </div>
                                            <div class="col"><s>$
                                                    <?php echo e(number_format($producto->precioClDi(), 0, '.', '.')); ?></s>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <strong><?php echo e($producto->nombre); ?></strong><br>
                                    <span><?php echo e($producto->descripcion); ?></span><br>
                                    <div class="espacio-promo">
                                        <?php if($producto->promocion() !== null): ?>
                                            <div class="porcentaje-promocion"><?php echo e($producto->promocion()->porcentaje); ?> %
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>Lo sentimos, en este momento no tenemos promociones activas</p>
                        <?php endif; ?>                        
                    </div>
                </div>
            <?php else: ?>
                <div class="promociones no-promo">
                    <?php $__empty_1 = true; $__currentLoopData = $promociones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div>
                            <a href="<?php echo e(route('web.verProductoUnico', ['producto' => $producto])); ?>" class="producto">
                                <div class="imagen">
                                    <?php if($producto->fotoPpal() !== null && Storage::disk('public')->exists('productos/min_' . $producto->fotoPpal()->ruta)): ?>
                                        <img src="<?php echo e(Storage::url('productos/min_' . $producto->fotoPpal()->ruta)); ?>"
                                            alt="<?php echo e($producto->nombre); ?>" loading="lazy" />
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('img/web/placeholder-producto.png')); ?>" loading="lazy" /><?php echo e($producto->fotoPpal()); ?>

                                    <?php endif; ?>
                                </div>
                                <div class="row">
                                    <?php if($producto->promocion() === null): ?>
                                        <div class="col"><b>$
                                                <?php echo e(number_format($producto->precioClDi(), 0, '.', '.')); ?></b>
                                        </div>
                                    <?php else: ?>
                                        <div class="col-7"><b>$
                                                <?php echo e(number_format($producto->precioPromo(), 0, '.', '.')); ?></b>
                                        </div>
                                        <div class="col-5 text-end"><s>$
                                                <?php echo e(number_format($producto->precioClDi(), 0, '.', '.')); ?></s>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <strong><?php echo e($producto->nombre); ?></strong><br>
                                <span><?php echo e($producto->descripcion); ?></span><br>
                                <div class="espacio-promo">
                                    <?php if($producto->promocion() !== null): ?>
                                        <div class="porcentaje-promocion"><?php echo e($producto->promocion()->porcentaje); ?> %</div>
                                    <?php endif; ?>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>Lo sentimos, en este momento no tenemos promociones activas</p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

        </div>
    </section>
    <section class="categorias">

        <div class="container">
            <h2 class="text-center">Conoce todo lo que tenemos para tí</h2>
            <div class="fila">
                
                <?php $__currentLoopData = $categorias_principales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-categoria">
                        
                        <a href="<?php echo e(route('web.verProductos',['categoria' => $categoria])); ?>" class="categoria-ppal">
                            <div class="cat_cont">
                            <img <?php if(!empty(trim($categoria->imagen)) && Storage::disk('public')->exists('categorias/max_' . $categoria->imagen)): ?> src="<?php echo e(Storage::url('categorias/max_' . $categoria->imagen)); ?>"
                        <?php else: ?>
                        src="<?php echo e(asset('img/web/placeholder-categoria.png')); ?>" <?php endif; ?>
                                alt="<?php echo e($categoria->nombre); ?>" />
                            </div>
                            <span><?php echo e($categoria->nombre); ?></span>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('imports'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        const swiper = new Swiper('.swiper-web-1', {
            direction: 'horizontal',
            loop: true
        });
        const swiper_2 = new Swiper(".swiper-promo", {
            lazy: true,
            lazyPreloaderClass: 'lazy-preloader',
            slidesPerView: 4,
            spaceBetween: 50,
            freemode: true,
            navigation: {
                nextEl: ".gorila-button-next",
                prevEl: ".gorila-button-prev",
            },
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web_sin_cat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/web/index.blade.php ENDPATH**/ ?>