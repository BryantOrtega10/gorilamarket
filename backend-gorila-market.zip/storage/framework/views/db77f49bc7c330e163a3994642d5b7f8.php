<nav class="navbar navbar-gorila">
    <div class="navbar-left">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('img/web/logo.png')); ?>" alt="Gorila Market">
        </a>
        <a class="navbar-direccion btn" href="<?php echo e(route('web.direccion.mostrar')); ?>">
            <img src="<?php echo e(asset('img/web/direccion.png')); ?>" class="img-direccion">
            <?php if(Session::has('direccion')): ?>
                <?php echo e(Session::get('direccion')->direccionCompleta); ?>

            <?php else: ?>
                Selecciona una dirección
            <?php endif; ?>
        </a>
    </div>
    <div class="navbar-center">
        <div class="navbar-search">
            <form class="search-form" action="<?php echo e(route('web.buscarProducto')); ?>">
                
                <input class="form-control" type="text" placeholder="Huevos, arroz, carne, vino"
                    aria-label="Buscador" name="query">
                <button type="submit" class="btn">
                    <img src="<?php echo e(asset('img/web/buscar-azul.png')); ?>" />
                </button>
            </form>
        </div>
    </div>
    <div class="navbar-right">
        <div class="navbar-buttons">
            <a class="btn btn-icono btn-ingresar" <?php if(auth()->guard()->guest()): ?> href="<?php echo e(route('web.ingresar')); ?>" <?php else: ?> href="<?php echo e(route('web.micuenta')); ?>" <?php endif; ?>>
                <img src="<?php echo e(asset('img/web/ingresar.png')); ?>" class="img-ingresar">
                <?php if(auth()->guard()->guest()): ?>
                    <span class="span-ingresar">Ingresar</span>
                <?php else: ?>
                    <span class="span-ingresar">Hola, <?php echo e(Auth::user()->name); ?></span>
                <?php endif; ?>
            </a>
            <a href="<?php echo e(route('web.mostrar')); ?>" class="btn btn-icono btn-carrito">
                <img src="<?php echo e(asset('img/web/carrito.png')); ?>">
                <span class="cantidad-productos <?php if(!Session::has('carrito') || Session::get('carrito')->cuentaProductos == 0): ?> d-none <?php endif; ?>"><?php echo e(Session::get('carrito')->cuentaProductos ?? 0); ?></span>
                <span>Carrito</span>
            </a>
        </div>
    </div>
</nav><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/layouts/partials/web/header.blade.php ENDPATH**/ ?>