<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>Pagos administrar</title>
    <style type="text/css">
        body {
            margin: 0;
            padding: 0;
            font-family: sans-serif;
            text-align: center;
        }

        .respuesta_pop {
            overflow: visible;
            width: 80mm;
            height: auto;
            max-height: none;
            text-align: left;
        }

        .respuesta_pop div {
            font-size: 12px;
        }

        .linea_usuario span {
            padding: 0;
        }

        .datos_usuario {
            padding: 0;
            border: 0;
        }

        .content-imp {
            width: 80mm;
            margin: auto;
        }

        .content-imp .cont-prod:nth-of-type(2n) {
            background: #f5f5f5;
        }

        
    </style>
</head>

<body>
    <div class="content-imp">

        <div class="respuesta_pop">
            <h3>Datos Pedido</h3>
            <div><b>Observaciones Domiciliario:</b> <?php echo e($pago->ultima_observacion); ?></div>
            <div><b>Total:</b> $<?php echo e(number_format($pago->valor + $pago->descuento - $pago->csto_Dom, 0, '.', '.')); ?>

            </div>
            <div><b>Domicilio:</b> $<?php echo e(number_format($pago->csto_Dom, 0, '.', '.')); ?></div>
            <?php if($pago->cd_referido != ''): ?>
                <div><b>Descuento:</b> $<?php echo e(number_format($pago->descuento, 0, '.', '.')); ?></div>
                <div><b>Valor a pagar:</b> $<?php echo e(number_format($pago->valor, 0, '.', '.')); ?></div>
                <div><b>Código Referido:</b> <?php echo e($pago->cd_referido); ?></div>
            <?php else: ?>
                <div><b>Valor a pagar:</b> $<?php echo e(number_format($pago->valor, 0, '.', '.')); ?></div>
            <?php endif; ?>
            <div><b>Tipo Pago:</b> <?php echo e(ucfirst($pago->tipo_pago)); ?></div>
            <div><b>Fecha Entrega:</b> <?php echo e($pago->fecha_recib); ?></div>
            <div><b>Hora Entrega:</b> <?php echo e($pago->hora_cast()); ?></div>
            <div><b>Dirección:</b> <?php echo e($pago->direccion); ?></div>
            <div><b>Plataforma:</b> <?php echo e($pago->plataforma); ?></div>

            <h3>Cliente</h3>
            <div><b>Nombre:</b> <?php echo e($pago->cliente->nombre); ?></div>
            <div><b>Apellido:</b> <?php echo e($pago->cliente->apellido); ?></div>
            <div><b>Celular:</b> <?php echo e($pago->cliente->celular); ?></div>
            <div><b>Email:</b> <?php echo e($pago->cliente->email); ?></div>

            <h3>Productos</h3>
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="cont-prod">
                    <div><b>Nombre:</b> <?php echo e($producto->nombre); ?></div>
                    <div><b>Und. Medida</b> <?php echo e($producto->descripcion); ?></div>
                    <div><b>Cantidad</b> <?php echo e($producto->cantidad); ?></div>
                    <div><b>Precio mostrado</b> $<?php echo e(number_format($producto->precioMos, 0, '.', '.')); ?></div>
                    <?php if($producto->apPromocion == '1'): ?>
                        <div><b>Aplicó Promoción</b> SI</div>
                    <?php endif; ?>
                </div>
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <script type="text/javascript">
        window.print();
        //window.close();
    </script>
</body>

</html>
<?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/pago/imprimir.blade.php ENDPATH**/ ?>