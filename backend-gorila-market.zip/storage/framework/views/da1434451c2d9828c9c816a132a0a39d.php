

<?php $__env->startSection('title'); ?>
Registro
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('web.enviarCodigoRegistro')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="container vh-100 text-center registro">
            <div class="align-content-between h-100 row">
                <div class="col-12">
                    <h1>Registro</h1>
                    <h2>Numero de télefono</h2>
                    <p>Escribe el numero de tu teléfono donde llegara el código de confirmación </p>
                    <div>
                        <b>+57</b>
                        <input type="text" id="numeroTelefono" name="numeroTelefono" />
                    </div>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger  d-inline-block mt-4">
                            <strong><?php echo e(session('error')); ?></strong>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-12">
                    <button class="btn btn-verde">Continuar</button>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web_sin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/web/registroCelular.blade.php ENDPATH**/ ?>