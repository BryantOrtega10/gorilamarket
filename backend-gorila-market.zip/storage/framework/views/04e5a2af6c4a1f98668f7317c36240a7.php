<!DOCTYPE html>
<html>
<head>
    <title>Gorila Market</title>
</head>
<body>
    <h1><?php echo e($mailData['title']); ?></h1>
    <p><?php echo e($mailData['body']); ?></p>
</body>
</html><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/web/mails/pedidoRealizado.blade.php ENDPATH**/ ?>