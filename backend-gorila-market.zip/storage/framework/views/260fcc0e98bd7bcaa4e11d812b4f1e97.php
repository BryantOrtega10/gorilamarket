<!doctype html>
<html>

<head>
    <meta charset="utf-8">
</head>

<body>
    <table>
        <tr>
            <th>Cupon</th>
            <th>Cliente</th>
            <th>Id Pedido</th>
            <th>Monto Original</th>
            <th>Descuento</th>
            <th>Costo Domicilio</th>
            <th>Monto Final</th>
            <th>Fecha</th>
        </tr>
    <?php $__currentLoopData = $cupones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($cupon->cupon); ?></td>
            <td><?php echo e($cupon->cliente); ?></td>
            <td><?php echo e($cupon->idpago); ?></td>
            <td><?php echo e($cupon->montoOriginal); ?></td>
            <td><?php echo e($cupon->descuento); ?></td>
            <td><?php echo e($cupon->csto_Dom); ?></td>
            <td><?php echo e($cupon->montoFinal); ?></td>
            <td><?php echo e($cupon->fecha); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>

</html>
<?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/cupones/reportes/cupones.blade.php ENDPATH**/ ?>