

<?php $__env->startSection('title'); ?>
    Gracias
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container text-center gracias">
        <div class="row">
            <div class="col-12 py-5">
                <img src="<?php echo e(asset('img/web/logo_gracias.png')); ?>" />
            </div>
            <div class="col-12">
                <h2>¡Gracias!</h2>
                <p>Gracias por comprar en Gorilla Market, siempre buscaremos brindarte los mejores precios y el mejor servicio !Esperamos volver a verte pronto!</p>
                <a href="<?php echo e(route('web.index')); ?>" class="btn btn-verde">
                    Seguir comprando
                </a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.web_sin_cat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/web/gracias.blade.php ENDPATH**/ ?>