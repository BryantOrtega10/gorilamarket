<!doctype html>
<html>

<head>
    <meta charset="utf-8">
</head>

<body>
    <table>
        <tr>
            <th>Id Cliente</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Email</th>
            <th>Celular</th>
            <th>Código Referido</th>
            <th>Referidos</th>
        </tr>
    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($cliente->idcliente); ?></td>
            <td><?php echo e($cliente->nombre); ?></td>
            <td><?php echo e($cliente->apellido); ?></td>
            <td><?php echo e($cliente->email); ?></td>
            <td><?php echo e($cliente->celular); ?></td>
            <td><?php echo e($cliente->fijo); ?></td>
            <td><?php echo e($cliente->misreferidos); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>

</html>
<?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/pago/reportes/referidos.blade.php ENDPATH**/ ?>