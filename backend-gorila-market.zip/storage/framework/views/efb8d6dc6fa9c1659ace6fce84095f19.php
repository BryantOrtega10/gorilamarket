

<?php $__env->startSection('title', 'Historial de estados'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Historial de estados del pedido # <?php echo e($pago->idpago); ?></h1>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('pago.tabla')); ?>" class="color-azul">Pedidos</a></li>
            <li class="breadcrumb-item active" aria-current="page">Historial de estados</li>
        </ol>
    </nav>
   
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card card-verde">
                <div class="card-header">
                    <h3 class="card-title">Historial de estados</h3>
                </div>
                <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="row p-3 row-stripped">
                            <div class="col-10">
                                <b>Estado:</b> <?php echo e($estado->estado); ?><br>
                                <b>Descripcion:</b> <?php echo e($estado->descripcion); ?>

                            </div>
                            <div class="col-2 text-right"><?php echo e(substr($estado->fecha_sistema,0,10)); ?><br><?php echo e(substr($estado->fecha_sistema,11,5)); ?></div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="row">
                            <div class="col-12">
                                No hay cambios de estado registrados
                            </div>                        
                        </div>
                    <?php endif; ?>
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/app.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/pago/estados.blade.php ENDPATH**/ ?>