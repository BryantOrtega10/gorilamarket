<!DOCTYPE html>
<html>
<head>
    <title>Gorila Market</title>
</head>
<body>
    <h1>Nuevo producto sugerido</h1>
    <p>Se ha sugerido un producto al efectuar la compra<br>
        <b>Sugerencia:</b> <?php echo e($mailData['sugerencia']); ?><br>
        <b>Email:</b> <?php echo e($mailData['email']); ?><br>
    </p>
</body>
</html><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/web/mails/productoSugerido.blade.php ENDPATH**/ ?>