<!doctype html>
<html>

<head>
    <meta charset="utf-8">
</head>

<body>
    <table>
        <tr>
            <th>Id Producto</th>
            <th>Cliente Nombre</th>
            <th>Cliente Apellido</th>
            <th>Código de Barras</th>
            <th>Descripción producto</th>
            <th>Cantidad</th>
            <th>Precio</th>
        </tr>
    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($producto->idproducto); ?></td>
            <td><?php echo e($pago->cliente->nombre); ?></td>
            <td><?php echo e($pago->cliente->apellido); ?></td>
            <td>="<?php echo e($producto->cd_barras); ?>"</td>
            <td><?php echo e($producto->nombre); ?></td>
            <td><?php echo e($producto->cantidad); ?></td>
            <td><?php echo e($producto->precioMos); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>

</html>
<?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/pago/reportes/productosPedido.blade.php ENDPATH**/ ?>