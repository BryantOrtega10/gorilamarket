

<?php $__env->startSection('title'); ?>
    Mi Historial
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="container-fluid mi-cuenta mb-5 pe-5 pt-3">
        <div class="row align-items-center">
            <div class="col-md-8 d-flex align-items-center justify-content-start">
                <a href="<?php echo e(route('web.mihistorial')); ?>"><img class="me-3" src="<?php echo e(asset('img/web/volver.png')); ?>" /></a>
                <h1 class="d-inline-block"><i class="fa-solid fa-scroll"></i> Historial de compras</h1>
            </div>
        </div>
        <?php if(session('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
        <div class="row pt-5">
            <div class="col-6">
                <span class="color-azul">Fecha</span>
            </div>
            <div class="col-6 text-end">
                <span class="color-gris"><?php echo e(date("d/m/Y",strtotime($pago->fecha_recib))); ?></span>
            </div>
        </div>
        <div class="row">
            <div class="col-6">
                <span class="color-azul">Dirección</span>
            </div>
            <div class="col-6 text-end">
                <span class="color-gris"><?php echo e($pago->direccion); ?></span>
            </div>
        </div>
        <div class="row">
            <div class="col-6">
                <span class="color-azul">Hora</span>
            </div>
            <div class="col-6 text-end">
                <span class="color-gris"><?php echo e($pago->hora_cast()); ?></span>
            </div>
        </div>
        <div class="cont-productos-historial py-5">
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row align-items-center">
                    <div class="col-8">
                        <div class="producto-hist">
                            <span class="cantidad <?php if($producto->cantidad <= 1): ?> d-none <?php endif; ?>"><?php echo e($producto->cantidad); ?></span>
                            <div class="img-cont">
                                <?php if($producto->fotoPpal() !== null && Storage::disk('public')->exists('productos/min_' . $producto->fotoPpal()->ruta)): ?>
                                    <img src="<?php echo e(Storage::url('productos/min_' . $producto->fotoPpal()->ruta)); ?>"
                                        alt="<?php echo e($producto->nombre); ?>" loading="lazy" />
                                <?php else: ?>
                                    <img src="<?php echo e(asset('img/web/placeholder-producto.png')); ?>" loading="lazy" /><?php echo e($producto->fotoPpal()); ?>

                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="datos-prod">
                            <b class="color-azul"><?php echo e($producto->nombre); ?></b><br>
                            <span class="color-gris"><?php echo e($producto->descripcion); ?></span>
                        </div>
                    </div>
                    <div class="col-4 text-end">
                        <b class="color-azul">$<?php echo e(number_format($producto->precioMos,0,'.','.')); ?></b>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        const inputs = document.querySelectorAll(".form-control");
        inputs.forEach(element => {
            element.addEventListener("focus", (e) => {
                const label = e.target.previousElementSibling;
                label.classList.add('focus-label');
            });
            element.addEventListener("blur", (e) => {
                const label = e.target.previousElementSibling;
                label.classList.remove('focus-label');
                let cambio = false;
                inputs.forEach(element2 => {
                    const input_h = document.querySelector(`#${element2.id}Ant`);
                    if(input_h !== null && input_h.value != element2.value){
                        cambio = true;
                    }
                });
                const btnGuardar = document.querySelector(`.btn-guardar`);
                btnGuardar.disabled = !cambio;
            });
        });
        // document.querySelector("#distribuidor").addEventListener("change",(e) => {
        //     if(document.querySelector("#distribuidor").checked){
        //         document.querySelector(".rut-cont").classList.remove("d-none");
        //     }
        //     else{
        //         document.querySelector(".rut-cont").classList.add("d-none");
        //     }
        // });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web_perfil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/web/verDetalle.blade.php ENDPATH**/ ?>