<aside class="carrito">
    <div class="container-fluid">
        <div class="row">
            <div class="col-10">
                <h3>Tu carrito</h3>
            </div>
            <div class="col-2">
                <div class="cerrar_carrito"></div>
            </div>
        </div>
        <div class="productos-carrito">
            <?php $__currentLoopData = $carrito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="producto" data-id="<?php echo e($producto->idproducto); ?>">
                    <div class="row">
                        <div class="col-auto">
                            <div class="imagen">
                                <?php if($producto->fotoPpal() !== null && Storage::disk('public')->exists('productos/min_' . $producto->fotoPpal()->ruta)): ?>
                                    <img src="<?php echo e(Storage::url('productos/min_' . $producto->fotoPpal()->ruta)); ?>"
                                        alt="<?php echo e($producto->nombre); ?>" loading="lazy" />
                                <?php else: ?>
                                    <img src="<?php echo e(asset('img/web/placeholder-categoria.png')); ?>" loading="lazy" />
                                <?php endif; ?>
                                <div class="lazy-preloader">
                                    <img src="<?php echo e(asset('img/web/placeholder-categoria.png')); ?>" />
                                </div>
                            </div>
                            <?php if($producto->promocion() !== null && intval($producto->promocion()->porcentaje) > 0): ?>
                                <div class="espacio-promo">
                                    <div class="porcentaje-promocion">
                                        <?php echo e($producto->promocion()->porcentaje); ?> %</div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="col">
                            <div class="row">
                                <div class="col-12">
                                    <strong><?php echo e($producto->nombre); ?></strong><br>
                                    <span><?php echo e($producto->descripcion); ?></span><br>
                                </div>
                            </div>
                            <div class="row py-4">
                                <?php if($producto->promocion() === null): ?>
                                    <div class="col"><b class="precio1" data-id="<?php echo e($producto->idproducto); ?>">$
                                            <?php echo e(number_format($producto->precioClDi() * Session::get('carrito')->productos[$producto->idproducto], 0, '.', '.')); ?></b>
                                            <s class="precio2 d-none" data-id="<?php echo e($producto->idproducto); ?>">$
                                                <?php echo e(number_format($producto->precioClDi() * Session::get('carrito')->productos[$producto->idproducto], 0, '.', '.')); ?></s>
                                    </div>
                                <?php else: ?>
                                    <div class="col-auto"><b class="precio1" data-id="<?php echo e($producto->idproducto); ?>">$
                                            <?php echo e(number_format($producto->precioPromo() * Session::get('carrito')->productos[$producto->idproducto], 0, '.', '.')); ?></b>
                                    </div>
                                    <div class="col"><s class="precio2" data-id="<?php echo e($producto->idproducto); ?>">$
                                            <?php echo e(number_format($producto->precioClDi() * Session::get('carrito')->productos[$producto->idproducto], 0, '.', '.')); ?></s>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <a href="<?php echo e(route('web.quitarCarrito',['id' => $producto->idproducto])); ?>" class="menos-unidades"><i class="fa-solid fa-minus"></i></a>
                                    <span class="cant-productos-carrito" data-id="<?php echo e($producto->idproducto); ?>"><?php echo e(Session::get('carrito')->productos[$producto->idproducto]); ?></span>
                                    <a href="<?php echo e(route('web.agregarCarrito',['id' => $producto->idproducto])); ?>" class="mas-unidades"><i class="fa-solid fa-plus"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <a href="<?php echo e(route('web.pagar')); ?>" class="btn btn-pagar">
            <div class="row">
                <div class="col-5 text-start">
                    <b>Pagar</b>
                </div>
                <div class="col-7 text-end">
                    Subtotal <b class="subtotal">$<?php echo e(number_format(Session::get('carrito')->subtotal ?? 0, 0, ".",".")); ?></b>
                </div>
            </div>
        </a>
        <div class="text-center">
            <a href="<?php echo e(route('web.vaciar')); ?>" class="btn btn-vaciar">
                Vaciar canasta <img src="<?php echo e(asset('img/web/vaciar.png')); ?>" />
            </a>
        </div>
    </div>
</aside>
<div class="overlay-carrito"></div><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/layouts/partials/web/carrito.blade.php ENDPATH**/ ?>