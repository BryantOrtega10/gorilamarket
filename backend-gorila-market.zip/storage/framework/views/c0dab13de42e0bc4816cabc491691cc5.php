

<?php $__env->startSection('title', 'Agregar producto desde CSV'); ?>

<?php $__env->startSection('plugins.JQueryNumberFormat', true); ?>


<?php $__env->startSection('content_header'); ?>
    <h1>Agregar Producto desde CSV</h1>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('producto.tabla')); ?>" class="color-azul">Productos</a></li>
            <li class="breadcrumb-item active" aria-current="page">Agregar desde CSV</li>
        </ol>
    </nav>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php if(session('mensaje')): ?>
            <div class="alert alert-success">
                <?php echo e(session('mensaje')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <strong><?php echo e(session('error')); ?></strong>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-12">
                <div class="card card-verde my-4">
                    <h1>Resultados de la subida</h1>
                    <ol>
                    <?php $__empty_1 = true; $__currentLoopData = $resultados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li><?php echo e($resultado); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li>No se encontraron datos</li>
                    <?php endif; ?>
                    </ol>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/app.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        
        $('#archivoCSV').on('change', function() {
            const nombre = $(this).val();
            const inp = $(this)[0];
            let textoHtml = '';
            for (let i = 0; i < inp.files.length; ++i) {
                const name = inp.files.item(i).name;
                textoHtml += name + ", ";
            }
            textoHtml = textoHtml.slice(0, textoHtml.length - 2)
            $(this).next('.custom-file-label').html(textoHtml);
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/productos/resultadosMasivo.blade.php ENDPATH**/ ?>