

<?php $__env->startSection('title'); ?>
    <?php echo e($categoriaSelect->nombre); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('web.index')); ?>" class="color-azul">Gorila market</a></li>
            <?php if($subCategoriaSelect !== null): ?>
                <li class="breadcrumb-item">
                    <a
                        href="<?php echo e(route('web.verProductos', ['categoria' => $categoriaSelect])); ?>"><?php echo e(ucfirst(strtolower($categoriaSelect->nombre))); ?></a>
                </li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e(ucfirst(strtolower($subCategoriaSelect->nombre))); ?>

                </li>
            <?php else: ?>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e(ucfirst(strtolower($categoriaSelect->nombre))); ?>

                </li>
            <?php endif; ?>
        </ol>
    </nav>
    <section class="categoria">
        <?php if($subCategoriaSelect !== null): ?>
            <?php if(sizeof($productos) > 0): ?>
                <article class="sub-categoria">
                    <div class="row">
                        <div class="col-12 col-md-8">
                            <h2><?php echo e($subCategoriaSelect->nombre); ?></h2>
                        </div>

                    </div>

                    <div class="productos">
                        <div class="no-swipe">
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item-no-swipe">
                                    <a href="<?php echo e(route('web.verProductoUnico', ['producto' => $producto])); ?>" class="producto">
                                        <div class="agregar-carrito"
                                            data-url="<?php echo e(route('web.agregarCarrito', ['id' => $producto->idproducto])); ?>">
                                            <div class="icono-carrito">
                                                <i class="fa-solid fa-plus"></i>
                                            </div>
                                        </div>
                                        <div class="imagen">
                                            <?php if($producto->fotoPpal() !== null && Storage::disk('public')->exists('productos/min_' . $producto->fotoPpal()->ruta)): ?>
                                                <img src="<?php echo e(Storage::url('productos/min_' . $producto->fotoPpal()->ruta)); ?>"
                                                    alt="<?php echo e($producto->nombre); ?>" loading="lazy" />
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('img/web/placeholder-producto.png')); ?>"
                                                    loading="lazy" />
                                            <?php endif; ?>
                                            <div class="lazy-preloader">
                                                <img src="<?php echo e(asset('img/web/placeholder-producto.png')); ?>" />
                                            </div>
                                        </div>
                                        <div class="row">
                                            <?php if($producto->promocion() === null): ?>
                                                <div class="col"><b>$
                                                        <?php echo e(number_format($producto->precioClDi(), 0, '.', '.')); ?></b>
                                                </div>
                                            <?php else: ?>
                                                <div class="col-auto"><b>$
                                                        <?php echo e(number_format($producto->precioPromo(), 0, '.', '.')); ?></b>
                                                </div>
                                                <div class="col"><s>$
                                                        <?php echo e(number_format($producto->precioClDi(), 0, '.', '.')); ?></s>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <strong><?php echo e($producto->nombre); ?></strong><br>
                                        <span><?php echo e($producto->descripcion); ?></span><br>

                                        <?php if($producto->promocion() !== null && intval($producto->promocion()->porcentaje) > 0): ?>
                                            <div class="espacio-promo">
                                                <div class="porcentaje-promocion">
                                                    <?php echo e($producto->promocion()->porcentaje); ?> %</div>
                                            </div>
                                        <?php endif; ?>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </article>
            <?php endif; ?>
        <?php else: ?>
            <?php $__currentLoopData = $categoriaSelect->sub_categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(sizeof($productos[$subcategoria->idcategorias]) > 0): ?>
                    <article class="sub-categoria">
                        <div class="row">
                            <div class="col-12 col-md-8">
                                <h2><?php echo e($subcategoria->nombre); ?></h2>
                            </div>

                        </div>

                        <div class="productos swiper swiper-producto">
                            <div class="swipper-navigation-container">
                                <div class="gorila-button-next"><i class="fa-solid fa-chevron-right"></i></div>
                                <div class="gorila-button-prev"><i class="fa-solid fa-chevron-left"></i></div>
                                <div class="ver-mas-superior"><a
                                        href="<?php echo e(route('web.verProductos', ['categoria' => $categoriaSelect, 'sub_categoria' => $subcategoria])); ?>">Ver
                                        Mas</a></div>
                            </div>
                            <div class="swiper-wrapper">
                                <?php $__currentLoopData = $productos[$subcategoria->idcategorias]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="swiper-slide">
                                        <a href="<?php echo e(route('web.verProductoUnico', ['producto' => $producto])); ?>" class="producto">
                                            <div class="agregar-carrito"
                                                data-url="<?php echo e(route('web.agregarCarrito', ['id' => $producto->idproducto])); ?>">
                                                <div class="icono-carrito">
                                                    <i class="fa-solid fa-plus"></i>
                                                </div>
                                            </div>
                                            <div class="imagen">
                                                <?php if($producto->fotoPpal() !== null && Storage::disk('public')->exists('productos/min_' . $producto->fotoPpal()->ruta)): ?>
                                                    <img src="<?php echo e(Storage::url('productos/min_' . $producto->fotoPpal()->ruta)); ?>"
                                                        alt="<?php echo e($producto->nombre); ?>" loading="lazy" />
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('img/web/placeholder-producto.png')); ?>"
                                                        loading="lazy" />
                                                <?php endif; ?>
                                                <div class="lazy-preloader">
                                                    <img src="<?php echo e(asset('img/web/placeholder-producto.png')); ?>" />
                                                </div>
                                            </div>
                                            <div class="row">
                                                <?php if($producto->promocion() === null): ?>
                                                    <div class="col"><b>$
                                                            <?php echo e(number_format($producto->precioClDi(), 0, '.', '.')); ?></b>
                                                    </div>
                                                <?php else: ?>
                                                    <div class="col-auto"><b>$
                                                            <?php echo e(number_format($producto->precioPromo(), 0, '.', '.')); ?></b>
                                                    </div>
                                                    <div class="col"><s>$
                                                            <?php echo e(number_format($producto->precioClDi(), 0, '.', '.')); ?></s>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                            <strong><?php echo e($producto->nombre); ?></strong><br>
                                            <span><?php echo e($producto->descripcion); ?></span><br>

                                            <?php if($producto->promocion() !== null && intval($producto->promocion()->porcentaje) > 0): ?>
                                                <div class="espacio-promo">
                                                    <div class="porcentaje-promocion">
                                                        <?php echo e($producto->promocion()->porcentaje); ?> %</div>
                                                </div>
                                            <?php endif; ?>
                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide">
                                    <div class="ver-mas-interno">
                                        <a
                                            href="<?php echo e(route('web.verProductos', ['categoria' => $categoriaSelect, 'sub_categoria' => $subcategoria])); ?>">
                                            <i class="fa-solid fa-arrow-right"></i>
                                            <span>Ver Mas</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </article>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>


    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('imports'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        const swiper_2 = new Swiper(".swiper-producto", {
            lazy: true,
            lazyPreloaderClass: 'lazy-preloader',
            slidesPerView: 4,
            spaceBetween: 20,
            freemode: true,
            navigation: {
                nextEl: ".gorila-button-next",
                prevEl: ".gorila-button-prev",
            },
            breakpoints: {
                1400: {
                    slidesPerView: 7,
                    spaceBetween: 50
                },
                1200: {
                    slidesPerView: 5,
                    spaceBetween: 50
                }
            }
        });

        

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web_con_cat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/web/verProductos.blade.php ENDPATH**/ ?>