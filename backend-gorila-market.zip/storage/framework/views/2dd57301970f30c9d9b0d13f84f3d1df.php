<div class="card card-verde my-4">
    <div class="card-header">
        <h3 class="card-title">Modificar Categoria</h3>
    </div>
    <form method="POST" action="<?php echo e(route('categoria.modificar', ['id' => $categoria_s->idcategorias])); ?>" enctype="multipart/form-data">
        <div class="card-body">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="m_idcategorias" value="<?php echo e($categoria_s->idcategorias); ?>" />
            <div class="form-group row ">
                <label for="m_nombre" class="col-4 col-form-label">Nombre</label>
                <div class="col">
                    <input id="m_nombre" type="text" class="form-control <?php $__errorArgs = ['m_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="m_nombre" value="<?php echo e(old('m_nombre', $categoria_s->nombre)); ?>" autocomplete="m_nombre"
                        autofocus>
                    <?php $__errorArgs = ['m_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group row ">
                <label for="m_tipo" class="col-4 col-form-label">Tipo</label>
                <div class="col">
                    <select id="m_tipo" class="form-control <?php $__errorArgs = ['m_tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="m_tipo">
                        <option value="1" <?php if(old('m_tipo', $categoria_s->tipo) == '1'): ?> selected <?php endif; ?>>Categoria Superior
                        </option>
                        <option value="2" <?php if(old('m_tipo', $categoria_s->tipo) == '2'): ?> selected <?php endif; ?>>Categoria Inferior
                        </option>
                    </select>
                    <?php $__errorArgs = ['m_tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group row <?php if(old('m_tipo', $categoria_s->tipo) != '2'): ?> d-none <?php endif; ?>" id="m_cat_general">
                <label for="m_padre_gen" class="col-4 col-form-label">Categoria General</label>
                <div class="col">
                    <select id="m_padre_gen" class="form-control <?php $__errorArgs = ['m_padre_gen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="m_padre_gen">
                        <option value="" class="d-none">Seleccione</option>
                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($categoria->idcategorias); ?>"
                                <?php if(old('m_padre_gen', $categoria_s->id_categoria_sup) == $categoria->idcategorias): ?> selected <?php endif; ?>><?php echo e($categoria->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['m_padre_gen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <span class="<?php if(old('m_tipo', $categoria_s->tipo) != '1'): ?> d-none <?php endif; ?>">No seleccionar ningun archivo para no modificar el icono</span> 
            <div class="form-group row <?php if(old('m_tipo', $categoria_s->tipo) != '1'): ?> d-none <?php endif; ?>" id="m_foto">
                <label for="m_foto" class="col-4 col-form-label">Icono</label>
                <div class="col">
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" name="m_foto" id="m_foto" accept="image/*">
                        <label class="custom-file-label" for="m_foto">Selecciona la imagen</label>
                    </div>
                    <?php $__errorArgs = ['m_foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        <div class="card-footer text-right">
            <a href="<?php echo e(route('categoria.eliminar', ['id' => $categoria_s->idcategorias])); ?>" type="button"
                id="eliminar" class="btn btn-azul">Eliminar</a>

                <button type="submit" class="btn btn-verde">Modificar</button>
        </div>
    </form>
</div>
<?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/categorias/ajax/modificar.blade.php ENDPATH**/ ?>