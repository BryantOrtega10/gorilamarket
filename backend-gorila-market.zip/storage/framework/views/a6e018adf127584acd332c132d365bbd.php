

<?php $__env->startSection('title'); ?>
    Mi cuenta
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="container-fluid mi-cuenta">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h1><i class="fa-regular fa-user"></i> Mi cuenta</h1>
            </div>
            <div class="col-md-4 color-azul text-end"><span class="text-start mi-codigo">Mi código de referido</span>
                <br>
                <span class="s_codigo_referido">
                    <?php echo e($cliente->fijo); ?> 
                    <img src="<?php echo e(asset('img/web/copiar.png')); ?>" />
                </span>
            </div>
        </div>
        <?php if(session('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('web.micuenta')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="nombreAnt" id="nombreAnt" value="<?php echo e($cliente->nombre); ?>" />
            <input type="hidden" name="apellidoAnt" id="apellidoAnt" value="<?php echo e($cliente->apellido); ?>" />
            <input type="hidden" name="correoAnt" id="correoAnt" value="<?php echo e($cliente->email); ?>" />
            
            <div class="row mt-5">
                <div class="form-group col-4">
                    <label for="nombre">Nombre</label>
                    <input type="text" name="nombre" id="nombre" class="form-control w-90 <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('nombre',$cliente->nombre)); ?>" />
                    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-4">
                    <label for="apellido">Apellido</label>
                    <input type="text" name="apellido" id="apellido" class="form-control w-90 <?php $__errorArgs = ['apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('apellido',$cliente->apellido)); ?>"/>
                    <?php $__errorArgs = ['apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-4">
                    <label for="correo">Correo</label>
                    <input type="email" name="correo" id="correo" class="form-control w-90 <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('correo',$cliente->email)); ?>"/>
                    <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-4">
                    <label for="celular">Celular</label>
                    <input type="number" name="celular" id="celular" disabled class="form-control w-90 <?php $__errorArgs = ['celular'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('celular',$cliente->celular)); ?>"/>
                    <img src="<?php echo e(asset('img/web/bloquear.png')); ?>" />
                    <?php $__errorArgs = ['celular'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="foot-mi-cuenta align-items-end d-flex justify-content-end mh-100">
                <button class="btn btn-verde btn-guardar" disabled>Guardar cambios</button>
            </div>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        const inputs = document.querySelectorAll(".form-control");
        inputs.forEach(element => {
            element.addEventListener("focus", (e) => {
                const label = e.target.previousElementSibling;
                label.classList.add('focus-label');
            });
            element.addEventListener("blur", (e) => {
                const label = e.target.previousElementSibling;
                label.classList.remove('focus-label');
                let cambio = false;
                inputs.forEach(element2 => {
                    const input_h = document.querySelector(`#${element2.id}Ant`);
                    if(input_h !== null && input_h.value != element2.value){
                        cambio = true;
                    }
                });
                const btnGuardar = document.querySelector(`.btn-guardar`);
                btnGuardar.disabled = !cambio;
            });
        });
        document.querySelector(".s_codigo_referido").addEventListener("click", (e) => {
            let tempInput = document.createElement("textarea");
            tempInput.style.position = "fixed";
            tempInput.style.opacity = 0;
            tempInput.value = `<?php echo e($cliente->fijo); ?>`;
            document.body.appendChild(tempInput);
            tempInput.select();
            document.execCommand("copy");
            document.body.removeChild(tempInput);
        });
        
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web_perfil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/web/micuenta.blade.php ENDPATH**/ ?>