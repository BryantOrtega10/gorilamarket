

<?php $__env->startSection('title', 'Asignar domiciliario'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Asignar domiciliario al pedido #<?php echo e($pago->idpago); ?></h1>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('pago.tabla')); ?>" class="color-azul">Pedidos</a></li>
            <li class="breadcrumb-item active" aria-current="page">Asignar domiciliario</li>
        </ol>
    </nav>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card card-verde">
                <form method="POST" action="<?php echo e(route('pago.domiciliario', ['id' => $pago->idpago])); ?>"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12 col-md-4 col-xl-3">
                                <div class="form-group">
                                    <label for="domiciliario" class="form-label">Domiciliario</label>
                                    <select id="domiciliario"
                                        class="form-control <?php $__errorArgs = ['domiciliario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="domiciliario">
                                        <option value="">Seleccione uno</option>
                                        <?php $__currentLoopData = $domiciliarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domiciliario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($domiciliario->iddomiciliario); ?>"
                                                <?php if(old('domiciliario', $domiciliarioSel->iddomiciliario ?? '') == $domiciliario->iddomiciliario): ?> selected <?php endif; ?>>
                                                <?php echo e($domiciliario->nombre); ?> <?php echo e($domiciliario->apellido); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['domiciliario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="card-footer text-right">
                        <button type="submit" class="btn btn-verde">Asignar domiciliario</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/app.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/pago/asignarDomiciliario.blade.php ENDPATH**/ ?>