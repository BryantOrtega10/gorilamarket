

<?php $__env->startSection('title', 'Detalle de pedido'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Detalle de pedido <?php echo e($pago->idpago); ?></h1>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('domiciliario.tabla')); ?>" class="color-azul">Domiciliarios</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('domiciliario.historial',['id' => $idDomiciliario])); ?>" class="color-azul">Historial</a></li>
            <li class="breadcrumb-item active" aria-current="page">Ver Detalle</li>
        </ol>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card card-verde">
        <div class="card-body">
            <div class="col-12 col-md-6">
                <a href="<?php echo e(route('pago.imprimir',['id' => $pago->idpago])); ?>" target="_blank" class="btn btn-outline-azul">Imprimir</a>
                <a href="<?php echo e(route('pago.generarXLS',['id' => $pago->idpago])); ?>" target="_blank" class="btn btn-outline-azul">Generar archivo XLS</a>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card card-verde">
                <div class="card-header">
                    <h3 class="card-title">Datos Pedido</h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-12"><b>Observaciones Domiciliario:</b> <?php echo e($pago->ultima_observacion); ?></div>
                    </div>
                    <div class="row">
                        <div class="col"><b>Total:</b> <br> $<?php echo e(number_format($pago->valor + $pago->descuento - $pago->csto_Dom,0,'.','.')); ?></div>
                        <div class="col"><b>Domicilio:</b> <br> $<?php echo e(number_format($pago->csto_Dom,0,'.','.')); ?></div>
                        <?php if($pago->cd_referido != ""): ?>
                            <div class="col"><b>Descuento:</b> <br> $<?php echo e(number_format($pago->descuento,0,'.','.')); ?></div>
                            <div class="col"><b>Valor a pagar:</b> <br> $<?php echo e(number_format($pago->valor,0,'.','.')); ?></div>
                            <div class="col"><b>Código Referido:</b> <br> <?php echo e($pago->cd_referido); ?></div>
                        <?php else: ?>
                            <div class="col"><b>Valor a pagar:</b> <br> $<?php echo e(number_format($pago->valor,0,'.','.')); ?></div>
                        <?php endif; ?>                        
                        <div class="col"><b>Tipo Pago:</b> <br> <?php echo e(ucfirst($pago->tipo_pago)); ?></div>
                    </div>
                    <div class="row my-4">
                        <div class="col"><b>Fecha Entrega:</b> <?php echo e($pago->fecha_recib); ?></div>
                        <div class="col"><b>Hora Entrega:</b> <?php echo e($pago->hora_cast()); ?></div>
                        <div class="col"><b>Dirección:</b> <?php echo e($pago->direccion); ?></div>
                        <div class="col"><b>Plataforma:</b> <?php echo e($pago->plataforma); ?></div>
                    </div>
                </div>
            </div>
            <div class="card card-verde">
                <div class="card-header">
                    <h3 class="card-title">Cliente</h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-3"><b>Nombre:</b> <?php echo e($pago->cliente->nombre); ?></div>
                        <div class="col-4"><b>Apellido:</b> <?php echo e($pago->cliente->apellido); ?></div>
                    </div>
                    <div class="row">
                        <div class="col-3"><b>Celular:</b> <?php echo e($pago->cliente->celular); ?></div>
                        <div class="col-4"><b>Email:</b> <?php echo e($pago->cliente->email); ?></div>
                    </div>                    
                </div>
            </div>
            <div class="card card-verde">
                <div class="card-header">
                    <h3 class="card-title">Productos</h3>
                </div>
                <div class="card-body">
                    <table class="table table-striped" id="tabla">
                        <thead>
                            <tr>
                                <th>Código Barras</th>
                                <th>Nombre</th>
                                <th>Und. Medida</th>
                                <th>Cantidad</th>
                                <th>Precio mostrado</th>
                                <th>Aplicó Promoción?</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($producto->cd_barras); ?></td>
                                    <td><?php echo e($producto->nombre); ?></td>
                                    <td><?php echo e($producto->descripcion); ?></td>
                                    <td><?php echo e($producto->cantidad); ?></td>
                                    <td>$<?php echo e(number_format($producto->precioMos,0,'.','.')); ?></td>
                                    <td><?php echo e(($producto->apPromocion == '1' ? 'SI' : 'NO')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/app.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $('#imagen').on('change', function() {
            const nombre = $(this).val();
            const inp = $(this)[0];
            let textoHtml = '';
            for (let i = 0; i < inp.files.length; ++i) {
                const name = inp.files.item(i).name;
                textoHtml += name + ", ";
            }
            textoHtml = textoHtml.slice(0, textoHtml.length - 2)
            $(this).next('.custom-file-label').html(textoHtml);
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/domiciliario/detalles.blade.php ENDPATH**/ ?>