

<?php $__env->startSection('title', 'Configuración'); ?>

<?php $__env->startSection('plugins.JQueryUI', true); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row">
        <div class="col-12 col-md-8">
            <h1>Orden Despacho</h1>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php if(session('mensaje')): ?>
            <div class="alert alert-success">
                <?php echo e(session('mensaje')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <strong><?php echo e(session('error')); ?></strong>
            </div>
        <?php endif; ?>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card card-verde">
                <form id="despacho" action="" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <ul id="sortable_cats">
                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="ui-state-default" id="sub_<?php echo e($categoria->orden_cat); ?>">
                                    <div class="row align-items-center">
                                        <div class="col-2 d-flex justify-content-center ">
                                            <span class="posicion_cat"><?php echo e($categoria->orden_cat + 1); ?></span>
                                        </div>
                                        <div class="col-10">
                                            <b><?php echo e($categoria->categoria_superior->nombre); ?></b><br>
                                            <?php echo e($categoria->nombre); ?>

                                        </div>
                                    </div>
                                    <input type="hidden" name="idcategorias[]" value="<?php echo e($categoria->idcategorias); ?>" />
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>

                    </div>
                    <div class="card-footer">
                        <div class="row justify-content-center">
                            <div class="col-12 text-right">
                                <button type="button" id="actualizar_o" class="btn btn-verde">Actualizar Orden</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/app.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(function() {
            $('[data-toggle="tooltip"]').tooltip()
        });
        $(document).ready(function(e) {
            $("#sortable_cats").sortable({
                placeholder: "ui-state-highlight"
            });
            $("#sortable_cats").on("sortbeforestop", function(event, ui) {
                $(".posicion_cat").each(function(index, element) {
                    $(element).html("");
                });
                let i = 1;
                $(".posicion_cat").each(function(index, element) {
                    $(element).html(i);
                    i++;
                });

            });
            $("#actualizar_o").click(function(e) {
                e.preventDefault();
                $("#despacho").prop("action", "<?php echo e(route('despacho.orden')); ?>")
                const sorted = $("#sortable_cats").sortable("toArray");
                let mensaje = "";
                let cuenta = 0;
                sorted.forEach(function(entry) {
                    mensaje = mensaje + '<input type="hidden" value="' + cuenta +
                        '" name="orden[]" />';
                    cuenta++;
                });
                $(this).after(mensaje);
                $("#despacho").submit();
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/categorias/orden.blade.php ENDPATH**/ ?>