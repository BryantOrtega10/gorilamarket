

<?php $__env->startSection('title'); ?>
    <?php echo e($producto->nombre); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('web.index')); ?>" class="color-azul">Gorila market</a>
            </li>
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('web.verProductos', ['categoria' => $producto->categoria->categoria_superior])); ?>">
                    <?php echo e(ucfirst(strtolower($producto->categoria->categoria_superior->nombre))); ?>

                </a>
            </li>
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('web.verProductos', ['categoria' => $producto->categoria])); ?>">
                    <?php echo e(ucfirst(strtolower($producto->categoria->nombre))); ?>

                </a>
            </li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e(ucfirst(strtolower($producto->nombre))); ?>

            </li>
        </ol>
    </nav>
    <section class="producto-unico">

        <div class="row">
            <div class="col-auto">
                <div class="swiper-fotos-min-producto-cont">
                    <div class="swiper swiper-min-fotos-producto">
                        <div class="swiper-wrapper">
                            <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide">
                                    <div class="cont-img-producto-unico-min">
                                        <img src="<?php echo e(Storage::url('productos/min_' . $foto->ruta)); ?>"
                                            alt="<?php echo e($producto->nombre); ?>" />
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="swiper-scrollbar"></div>
                    </div>
                </div>
                <div class="swiper-fotos-producto-cont">
                    <div class="swiper swiper-fotos-producto">
                        <div class="swiper-wrapper">
                            <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide">
                                    <div class="cont-img-producto-unico">
                                        <img src="<?php echo e(Storage::url('productos/max_' . $foto->ruta)); ?>"
                                            alt="<?php echo e($producto->nombre); ?>" />
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-auto">
                <h1><?php echo e($producto->nombre); ?></h1>
                <div class="row">
                    <?php if($producto->promocion() === null): ?>
                        <div class="col-auto"><b>$
                                <?php echo e(number_format($producto->precioClDi(), 0, '.', '.')); ?></b>
                        </div>
                    <?php else: ?>
                        <div class="col-auto"><b>$
                                <?php echo e(number_format($producto->precioPromo(), 0, '.', '.')); ?></b>
                        </div>
                        <div class="col-auto"><s>$
                                <?php echo e(number_format($producto->precioClDi(), 0, '.', '.')); ?></s>
                        </div>
                        <div class="col-auto">
                            <div class="espacio-promo">
                                <div class="porcentaje-promocion">
                                    <?php echo e($producto->promocion()->porcentaje); ?> %</div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="cont-unidades-prod">
                    <a href="#" class="menos-unidades-unico"><i class="fa-solid fa-minus"></i></a>
                    <span class="cant-productos-unico">1</span>
                    <a href="#" class="mas-unidades-unico"><i class="fa-solid fa-plus"></i></a>
                    <input type="hidden" id="unidades" value="1" />
                    <input type="hidden" id="precioProd" value="<?php echo e($producto->precioPromo()); ?>" />
                </div><br>
                <a href="<?php echo e(route('web.agregarCarrito', ['id' => $producto->idproducto])); ?>" class="btn btn-verde btn-agregar-unico">
                    <div class="row">
                        <div class="col-5 text-start">
                            <strong>Agregar</strong>
                        </div>
                        <div class="col-7 text-end">
                            <strong class="valor_u">$<?php echo e(number_format($producto->precioPromo(), 0, ".",".")); ?></strong>
                        </div>
                    </div>
                </a>              
            </div>
        </div>
    </section>
    <section class="productos-relacionados">
        <h2>Productos relacionados</h2>
        <div class="productos swiper swiper-producto">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $productosSugeridos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="swiper-slide">
                        <a href="<?php echo e(route('web.verProductoUnico', ['producto' => $producto])); ?>" class="producto">
                            <div class="agregar-carrito"
                                data-url="<?php echo e(route('web.agregarCarrito', ['id' => $producto->idproducto])); ?>">
                                <div class="icono-carrito">
                                    <i class="fa-solid fa-plus"></i>
                                </div>
                            </div>
                            <div class="imagen">
                                <?php if($producto->fotoPpal() !== null && Storage::disk('public')->exists('productos/min_' . $producto->fotoPpal()->ruta)): ?>
                                    <img src="<?php echo e(Storage::url('productos/min_' . $producto->fotoPpal()->ruta)); ?>"
                                        alt="<?php echo e($producto->nombre); ?>" loading="lazy" />
                                <?php else: ?>
                                    <img src="<?php echo e(asset('img/web/placeholder-producto.png')); ?>"
                                        loading="lazy" />
                                <?php endif; ?>
                                <div class="lazy-preloader">
                                    <img src="<?php echo e(asset('img/web/placeholder-producto.png')); ?>" />
                                </div>
                            </div>
                            <div class="row">
                                <?php if($producto->promocion() === null): ?>
                                    <div class="col"><b>$
                                            <?php echo e(number_format($producto->precioClDi(), 0, '.', '.')); ?></b>
                                    </div>
                                <?php else: ?>
                                    <div class="col-auto"><b>$
                                            <?php echo e(number_format($producto->precioPromo(), 0, '.', '.')); ?></b>
                                    </div>
                                    <div class="col"><s>$
                                            <?php echo e(number_format($producto->precioClDi(), 0, '.', '.')); ?></s>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <strong><?php echo e($producto->nombre); ?></strong><br>
                            <span><?php echo e($producto->descripcion); ?></span><br>

                            <?php if($producto->promocion() !== null && intval($producto->promocion()->porcentaje) > 0): ?>
                                <div class="espacio-promo">
                                    <div class="porcentaje-promocion">
                                        <?php echo e($producto->promocion()->porcentaje); ?> %</div>
                                </div>
                            <?php endif; ?>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('imports'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        const swiper = new Swiper(".swiper-min-fotos-producto", {
            direction: 'vertical',
            slidesPerView: 4,
            freeMode: true,
            spaceBetween: 10,
            watchSlidesProgress: true,
            scrollbar: {
                el: ".swiper-scrollbar",
                hide: true,
            }
        });
        const swiper_2 = new Swiper(".swiper-fotos-producto", {

            direction: 'vertical',
            thumbs: {
                swiper: swiper,
            },
        });

        const swiper_3 = new Swiper(".swiper-producto", {
            lazy: true,
            lazyPreloaderClass: 'lazy-preloader',
            slidesPerView: 4,
            spaceBetween: 20,
            freemode: true,
            breakpoints: {
                1400: {
                    slidesPerView: 7,
                    spaceBetween: 50
                },
                1200: {
                    slidesPerView: 5,
                    spaceBetween: 50
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web_con_cat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/web/verProductoUnico.blade.php ENDPATH**/ ?>