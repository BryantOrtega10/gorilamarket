

<?php $__env->startSection('title', 'Pedidos'); ?>

<?php $__env->startSection('plugins.Sweetalert2', true); ?>
<?php $__env->startSection('plugins.Datatables', true); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row">
        <div class="col-12 col-md-6">
            <h1>Pedidos</h1>
        </div>
        <div class="col-12 col-md-6 text-right">
            <a href="<?php echo e(route('pago.pedidosHoy')); ?>" class="btn btn-outline-azul">Pedidos de hoy</a>
            <a href="<?php echo e(route('pago.referidos')); ?>" class="btn btn-outline-azul">Generar excel referidos</a>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-12">
            <div class="card card-verde">
                <div class="card-header">
                    <h3 class="card-title">Buscar Pedido</h3>
                </div>
                <form method="POST" action="<?php echo e(route('pago.verificarExistencia')); ?>">
                    <div class="card-body">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="id_pedido" class="col-1 col-form-label">ID Pedido</label>
                            <div class="col-4">
                                <input id="id_pedido" type="text"
                                    class="form-control <?php $__errorArgs = ['id_pedido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="id_pedido"
                                    value="<?php echo e(old('id_pedido')); ?>" autocomplete="id_pedido" autofocus>
                                <?php $__errorArgs = ['id_pedido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-4"><button type="submit" class="btn btn-primary btn-verde">Ver Detalle</button></div>
                        </div>
                    </div>
                    
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php if(session('mensaje')): ?>
            <div class="alert alert-success">
                <?php echo e(session('mensaje')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <strong><?php echo e(session('error')); ?></strong>
            </div>
        <?php endif; ?>
        <?php if(session('warning')): ?>
            <div class="alert alert-warning">
                <strong><?php echo e(session('warning')); ?></strong>
            </div>
        <?php endif; ?>

    </div>
    <div class="card card-verde">
        <div class="card-header">
            <h3 class="card-title">Pedidos pendientes</h3>
        </div>
        <div class="card-body">
        <table class="table table-striped" id="tabla">
        <thead>
            <tr>
                <th>ID</th>
                <th>Responsable</th>
                <th>Cliente</th>
                <th>Fecha Despacho</th>
                <th>Franja horaria</th>
                <th>Medio de pago</th>
                <th>Valor</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($pago->idpago); ?></td>
                    <td><?php echo e(Auth::user()->name); ?></td>
                    <td><?php echo e($pago->cliente->nombre); ?> <?php echo e($pago->cliente->apellido); ?></td>
                    <td><?php echo e($pago->fecha_recib); ?></td>
                    <td><?php echo e($pago->hora_cast()); ?></td>
                    <td><?php echo e(ucfirst($pago->tipo_pago)); ?></td>
                    <td>$<?php echo e(number_format($pago->valor,0)); ?></td>
                    <td><?php echo e(strtoupper($pago->estado)); ?></td>
                    <td data-priority="0" style="white-space: nowrap">
                        <a href="<?php echo e(route('pago.detalles', ['id' => $pago->idpago])); ?>" class="btn btn-verde"
                            data-toggle="tooltip" data-placement="top" title="Ver Detalles"><i class="fas fa-eye"></i></a>
                        <a href="<?php echo e(route('pago.c_estado', ['id' => $pago->idpago])); ?>" class="btn btn-verde"
                            data-toggle="tooltip" data-placement="top" title="Cambiar Estado"><i class="fas fa-exchange-alt"></i></a>
                        <a href="<?php echo e(route('pago.estados', ['id' => $pago->idpago])); ?>" class="btn btn-verde"
                            data-toggle="tooltip" data-placement="top" title="Historial de estados"><i class="fas fa-history"></i></a>
                        <a href="<?php echo e(route('pago.domiciliario', ['id' => $pago->idpago])); ?>" class="btn btn-verde"
                            data-toggle="tooltip" data-placement="top" title="Asignar domiciliario"><i class="fas fa-truck"></i></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/app.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(function() {
            $('[data-toggle="tooltip"]').tooltip()
        });
        $('#tabla').DataTable({
            responsive: true,
            order: [
                [0, 'asc']
            ],
            language: {
                url: 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/es-MX.json'
            }
        });
        $('#tabla').on('draw.dt', function() {
            $('[data-toggle="tooltip"]').tooltip();
        });

        $("#formulario_busc").submit(function(e){
            e.preventDefault();
            window.open(`/pedidos/${$("#id_pedido").val()}/detalles`,'_self');

        })
       
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/pago/tabla.blade.php ENDPATH**/ ?>