

<?php $__env->startSection('title', 'Panel de control'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <ul data-widget="treeview">
        <li><a href="#3">One Level</a></li>
        <li class="nav-item">
            <a class="nav-link" href="#1">Multilevel</a>
            <ul class="nav-treeview">
                <li><a href="#2">Level 2</a></li>
            </ul>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#3">Multilevel</a>
            <ul class="nav-treeview">
                <li><a href="#4">Level 2</a></li>
                <li><a href="#5">Level 2</a></li>
                <li><a href="#6">Level 2</a></li>
            </ul>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#10">Multilevel</a>
            <ul class="nav-treeview">
                <li><a href="#7">Level 2</a></li>
                <li><a href="#8">Level 2</a></li>
                <li><a href="#9">Level 2</a></li>
            </ul>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $('ul').Treeview();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/panel-control/inicio.blade.php ENDPATH**/ ?>