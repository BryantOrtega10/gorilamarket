

<?php $__env->startSection('title'); ?>
    Mi Historial
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="container-fluid mi-cuenta mb-5 pe-5">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h1><i class="fa-solid fa-scroll"></i> Historial de compras</h1>
            </div>
        </div>
        <?php if(session('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
        <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <hr>
            <div class="row color-azul">
                <div class="col-md-2">
                    <b>Fecha</b><br>
                    <span class="color-gris"><?php echo e($pago->fecha_recib); ?></span>
                </div>
                <div class="col-md-2">
                    <b>Tipo de pago</b><br>
                    <span class="color-gris"><?php echo e(ucfirst($pago->tipo_pago)); ?></span>
                </div>
                <div class="col-md-2">
                    <b>Dirección</b><br>
                    <span class="color-gris"><?php echo e($pago->direccion); ?></span>
                </div>
                <div class="col-md-2">
                    <b>Valor</b><br>
                    <span class="color-gris">$<?php echo e(number_format($pago->valor,0,".",".")); ?></span>
                </div>
                <div class="col-md-4 text-end">
                    <a href="<?php echo e(route('web.verDetallePago',['id' => $pago->idpago])); ?>" class="color-verde ver-mas-historial">
                        Ver más <img src="<?php echo e(asset('img/web/flecha_verde.png')); ?>" />
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        const inputs = document.querySelectorAll(".form-control");
        inputs.forEach(element => {
            element.addEventListener("focus", (e) => {
                const label = e.target.previousElementSibling;
                label.classList.add('focus-label');
            });
            element.addEventListener("blur", (e) => {
                const label = e.target.previousElementSibling;
                label.classList.remove('focus-label');
                let cambio = false;
                inputs.forEach(element2 => {
                    const input_h = document.querySelector(`#${element2.id}Ant`);
                    if(input_h !== null && input_h.value != element2.value){
                        cambio = true;
                    }
                });
                const btnGuardar = document.querySelector(`.btn-guardar`);
                btnGuardar.disabled = !cambio;
            });
        });
        // document.querySelector("#distribuidor").addEventListener("change",(e) => {
        //     if(document.querySelector("#distribuidor").checked){
        //         document.querySelector(".rut-cont").classList.remove("d-none");
        //     }
        //     else{
        //         document.querySelector(".rut-cont").classList.add("d-none");
        //     }
        // });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web_perfil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/web/mihistorial.blade.php ENDPATH**/ ?>