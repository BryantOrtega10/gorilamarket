

<?php $__env->startSection('title', 'Cupones'); ?>

<?php $__env->startSection('plugins.Sweetalert2', true); ?>
<?php $__env->startSection('plugins.Datatables', true); ?>


<?php $__env->startSection('content_header'); ?>
    <div class="row">
        <div class="col-12 col-md-8">
            <h1>Cupones</h1>
        </div>
        <div class="col-12 col-md-4 text-right">
            <a href="<?php echo e(route('cupones.reporte')); ?>" class="btn btn-outline-azul">Reporte general</a>
            <a href="<?php echo e(route('cupones.agregar')); ?>" class="btn btn-outline-azul">Agregar Cupón</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php if(session('mensaje')): ?>
            <div class="alert alert-success">
                <?php echo e(session('mensaje')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <strong><?php echo e(session('error')); ?></strong>
            </div>
        <?php endif; ?>
    </div>
    <div class="card">
        <div class="card-body">
    <table class="table table-striped" id="tabla">
        <thead>
            <tr>
                <th>Cupon</th>
                <th>Valor</th>
                <th>Disponibles</th>
                <th>Usados</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $cupones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($cupon->cupon); ?></td>
                    <td><?php if($cupon->tipoValor == "2"): ?>
                        $<?php echo e(number_format($cupon->valor, 0, '.', '.')); ?>                        
                        <?php else: ?>
                        <?php echo e($cupon->valor); ?>%
                    <?php endif; ?>
                    </td>
                    <td><?php echo e($cupon->no_cupones); ?></td>
                    <td><?php echo e($cupon->diff_cupon); ?></td>
                    <td><?php echo e($cupon->estado); ?></td>
                    <td data-priority="0" style="white-space: nowrap">
                        <a href="<?php echo e(route('cupones.modificar', ['id' => $cupon->idcupon])); ?>" class="btn btn-verde"
                            data-toggle="tooltip" data-placement="top" title="Editar"><i class="fas fa-edit"></i></a>
                        <?php if($cupon->estado == "Activo"): ?>
                            <a href="<?php echo e(route('cupones.cambiarEs', ['id' => $cupon->idcupon])); ?>" class="btn btn-verde"
                            data-toggle="tooltip" data-placement="top" title="Bloquear"><i class="fas fa-lock"></i></a>    
                        <?php else: ?>
                            <a href="<?php echo e(route('cupones.cambiarEs', ['id' => $cupon->idcupon])); ?>" class="btn btn-verde"
                            data-toggle="tooltip" data-placement="top" title="Desbloquear"><i class="fas fa-unlock"></i></a>    
                        <?php endif; ?>                        
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/app.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(function() {
            $('[data-toggle="tooltip"]').tooltip()
        });
        $('#tabla').DataTable({
            responsive: true,
            order: [
                [0, 'asc']
            ],
            language: {
                url: 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/es-MX.json'
            }
        });
        $('#tabla').on('draw.dt', function() {
            $('[data-toggle="tooltip"]').tooltip();
        });
        $("body").on("click", ".eliminar", function(e) {
            e.preventDefault();
            const link = $(this).attr("href");
            Swal.fire({
                title: '<b>Eliminar Publicidad</b>',
                type: 'warning',
                text: 'En verdad desea eliminar esta publicidad?',
                showCloseButton: true,
                showCancelButton: true,
                confirmButtonText: 'Eliminar',
                cancelButtonText: 'Cancelar',
                confirmButtonColor: 'var(--color-verde)'
            }).then((result) => {
                if (result.value) {
                    window.open(link, '_self');
                }
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\Mdc\Gorilla_Market\BackendGorilaMarket\backend-gorila-market\resources\views/cupones/tabla.blade.php ENDPATH**/ ?>