<!DOCTYPE html>
<html>
<head>
    <title>Gorila Market</title>
</head>
<body>
    <h1>{{ $mailData['title'] }}</h1>
    <p>{{ $mailData['body'] }}</p>
</body>
</html>